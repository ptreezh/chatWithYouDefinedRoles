Chat4 Portable v1.0.0 
========================= 
 
Quick Start: 
1. Double-click setup.bat (first time only) 
2. Double-click go.bat to start 
3. Open http://localhost:3000 in browser 
 
Requirements: 
- Windows 10/11 
- Node.js installed 
- Internet connection for first run 
 
All data is saved locally in the data folder. 
